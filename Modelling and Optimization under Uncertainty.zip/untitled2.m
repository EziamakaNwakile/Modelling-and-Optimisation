%%Main Function

FitFunc = @FitnessFunction;

%%Setting Boundaries

LB = [5000 1000];
UB = [50000 10000];
nVar = 2;

%%Test the function

[x,fval] = ga(FitFunc, nVar)