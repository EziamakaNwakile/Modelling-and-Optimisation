x = [0, 1.5, 2, 3, 4, 5.8, 6.1, 7, 8, 10]
y = [0, 1, 2, 3, .9, 5,6, 7, 9, 10]
plot(x, y)


function y = FitnessFunction1(x)
y(1)=1.068*x(1) + 0.6745;

end
