
function y = FitnessFunction2(x)
y(2)=0.01356*x(1) + 4.281;

end
